package com.example.notifrdv.patientProfile;

// Importations pour les composants Android et les fonctionnalités
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.notifrdv.R;
import com.example.notifrdv.utils.database.Database;
import com.example.notifrdv.utils.database.Patient;

public class PatientProfileActivity extends AppCompatActivity {
    // Déclaration des éléments de l'interface utilisateur
    ImageView patientPicture;
    TextView patientName;
    TextView patientEmail;
    TextView patientPhoneNumber;
    TextView patientDateOfBirthAge;
    TextView patientHeight;
    TextView patientWeight;
    TextView patientGender;

    Patient patient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_patient_profile);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialisation des éléments de la barre de statut personnalisée
        ImageView statusBackIcon = findViewById(R.id.status_bar_back_arrow_icon);
        ImageView statusBarIcon = findViewById(R.id.status_bar_icon);
        TextView statusBarTitle = findViewById(R.id.status_bar_title);
        statusBackIcon.setOnClickListener(v -> finish());
        statusBarIcon.setImageResource(R.drawable.patient_white);
        statusBarTitle.setText(getString(R.string.patient_profile));

        // Initialisation des éléments pour l'édition
        ImageView editButton = findViewById(R.id.patient_profile_activity_edit_patient_info);
        patientPicture = findViewById(R.id.patient_profile_activity_patient_picture);
        patientName = findViewById(R.id.patient_profile_activity_patient_name);
        patientEmail = findViewById(R.id.patient_profile_activity_patient_email);
        patientPhoneNumber = findViewById(R.id.patient_profile_activity_patient_phone_number);
        patientDateOfBirthAge = findViewById(R.id.patient_profile_activity_patient_birth_date_age);
        patientHeight = findViewById(R.id.patient_profile_activity_patient_height); // Correction de l'ID
        patientWeight = findViewById(R.id.patient_profile_activity_patient_weight);
        patientGender = findViewById(R.id.patient_profile_activity_patient_gender);

        // Récupère les données du patient passées via l'intent
        patient = (Patient) getIntent().getSerializableExtra("patient");
        if (patient == null) {
            Log.e("PatientProfileActivity", "Patient data not received in Intent");
            Toast.makeText(this, "Error: Patient data not found", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        // Gère le clic sur le bouton d'édition
        editButton.setOnClickListener(v -> {
            Intent intent = new Intent(PatientProfileActivity.this, EditablePatientProfileActivity.class);
            intent.putExtra("patient", patient);
            startActivity(intent);
        });
    }

    // Met à jour l'affichage des données du patient lors du retour à l'activité
    @SuppressLint({"SetTextI18n", "DefaultLocale"})
    @Override
    protected void onResume() {
        super.onResume();

        try {
            // Recharge les données du patient via l'instance de Database
            patient = Database.getInstance().getPatientById(patient.getId());
            if (patient == null) {
                Log.e("PatientProfileActivity", "Failed to retrieve patient with ID: " + patient.getId());
                Toast.makeText(this, "Error: Patient not found in database", Toast.LENGTH_LONG).show();
                finish();
                return;
            }

            patientPicture.setImageResource(R.drawable.default_profile_picture);
            patientName.setText(patient.getName());
            patientEmail.setText(patient.getEmail());
            patientPhoneNumber.setText(patient.getPhoneNumber());
            patientHeight.setText("Height\n" + formatMeasurement(patient.getHeight()) + " cm");
            patientWeight.setText("Weight\n" + formatMeasurement(patient.getWeight()) + " Kg");
            patientGender.setText("Gender\n" + patient.getGender());

            // Formate la date de naissance et calcule l'âge
            int tempDateOfBirth = patient.getDateOfBirth();
            String dateOfBirth = String.format("%04d-%02d-%02d",
                    tempDateOfBirth / 10000,
                    (tempDateOfBirth % 10000) / 100,
                    tempDateOfBirth % 100);
            patientDateOfBirthAge.setText(dateOfBirth + " (" + patient.getAge() + " years-old )");
        } catch (Exception e) {
            Log.e("PatientProfileActivity", "Error in onResume: " + e.getMessage());
            Toast.makeText(this, "Error loading patient data", Toast.LENGTH_LONG).show();
            finish();
        }
    }

    // Formate une mesure pour éviter les décimales inutiles
    @SuppressLint("DefaultLocale")
    private String formatMeasurement(double value) {
        if (value == (int) value) {
            return String.format("%d", (int) value);
        } else {
            return String.format("%.2f", value);
        }
    }
}