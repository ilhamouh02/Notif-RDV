package com.example.notifrdv.login;

// Importations pour les composants Android et les fonctionnalités
import android.content.Intent; // Pour naviguer entre les activités
import android.os.Bundle; // Pour gérer les données de l'activité
import android.widget.EditText; // Champ de texte éditable

import androidx.activity.EdgeToEdge; // Pour un affichage bord à bord
import androidx.appcompat.app.AppCompatActivity; // Activité de base compatible avec les versions Android
import androidx.appcompat.widget.AppCompatButton; // Bouton compatible avec Material Design
import androidx.core.graphics.Insets; // Pour gérer les marges des barres système
import androidx.core.view.ViewCompat; // Compatibilité pour les vues
import androidx.core.view.WindowInsetsCompat; // Gestion des insets des barres système

import com.example.notifrdv.R; // Fichier de ressources généré
import com.example.notifrdv.home.HomeActivity; // Activité principale (écran d'accueil)
import com.example.notifrdv.utils.FastToast; // Utilitaire pour afficher des messages toast
import com.example.notifrdv.utils.database.Database; // Classe pour gérer la base de données

public class RegisterActivity extends AppCompatActivity {
    // Déclaration des éléments de l'interface utilisateur
    EditText registerNameEDT; // Champ pour le nom du médecin
    EditText registerEmailEDT; // Champ pour l'email d'inscription
    EditText registerPasswordEDT; // Champ pour le mot de passe d'inscription

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this); // Active l'affichage bord à bord
        setContentView(R.layout.activity_register); // Charge le layout de l'activité
        // Gère les marges des barres système (status bar, navigation bar)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialisation du bouton d'inscription
        AppCompatButton registerButton = findViewById(R.id.register_activity_button);

        // Initialisation des champs de saisie
        registerNameEDT = findViewById(R.id.register_activity_name); // Champ pour le nom
        registerEmailEDT = findViewById(R.id.register_activity_email); // Champ pour l'email
        registerPasswordEDT = findViewById(R.id.register_activity_password); // Champ pour le mot de passe

        // Gère le clic sur le bouton d'inscription
        registerButton.setOnClickListener(view -> {
            String name = registerNameEDT.getText().toString().trim();
            String email = registerEmailEDT.getText().toString().trim();
            String password = registerPasswordEDT.getText().toString().trim();

            if (areFieldsValid(name, email, password)) {
                // Tente d'ajouter le médecin à la base de données
                long doctorId = Database.addDoctor(name, email, password, ""); // Spécialité vide pour l'instant
                if (doctorId != -1) {
                    FastToast.show(getApplicationContext(), "Registration successful");
                    startActivity(new Intent(RegisterActivity.this, HomeActivity.class)); // Redirige vers l'écran d'accueil
                    finish(); // Ferme l'activité d'inscription
                } else {
                    FastToast.show(getApplicationContext(), "Email already exists or error occurred");
                }
            } else {
                FastToast.show(getApplicationContext(), "Please fill all fields");
            }
        });
    }

    // Vérifie si tous les champs sont remplis
    private boolean areFieldsValid(String name, String email, String password) {
        return !name.isEmpty() && !email.isEmpty() && !password.isEmpty();
    }
}