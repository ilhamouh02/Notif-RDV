package com.example.notifrdv.home;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.content.res.AppCompatResources;
import androidx.recyclerview.widget.RecyclerView;

import com.example.notifrdv.R; // Fichier de ressources généré
import com.example.notifrdv.utils.database.Appointment; // Modèle de données pour un rendez-vous

import java.util.List;

public class HomeActivityAppointmentsAdapter extends RecyclerView.Adapter<HomeActivityAppointmentsAdapter.AppointmentViewHolder> {

    private final List<Appointment> appointmentList; // Liste des rendez-vous
    private final OnItemClickListener listener; // Interface pour gérer les clics

    // Interface pour écouter les clics sur les éléments
    public interface OnItemClickListener {
        void onItemClick(Appointment appointment);
    }

    // Constructeur de l'adaptateur
    public HomeActivityAppointmentsAdapter(List<Appointment> appointmentList, OnItemClickListener listener) {
        this.appointmentList = appointmentList;
        this.listener = listener;
    }

    // Crée un nouveau ViewHolder pour un élément de la liste
    @NonNull
    @Override
    public AppointmentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.activity_home_item, parent, false); // Charge le layout de l'élément
        return new AppointmentViewHolder(view);
    }

    // Lie les données à un ViewHolder pour un élément spécifique
    @SuppressLint({"SetTextI18n", "DefaultLocale"})
    @Override
    public void onBindViewHolder(@NonNull AppointmentViewHolder holder, int position) {
        Appointment appointment = appointmentList.get(position); // Récupère le rendez-vous à la position donnée

        // Met à jour les champs du ViewHolder avec les données du rendez-vous
        holder.patientName.setText(appointment.getPatient().getName()); // Nom du patient
        holder.patientAge.setText(appointment.getPatient().getAge() + " years-old"); // Âge du patient
        holder.appointmentType.setText("Regular Consultation"); // Type de rendez-vous (fixe)

        int hour = appointment.getAppointmentTime() / 100; // Heure
        int minute = appointment.getAppointmentTime() % 100; // Minutes
        holder.appointmentTime.setText(String.format("%02d:%02d", hour, minute)); // Heure au format HH:MM

        // Alterne les couleurs de fond pour l'heure (vert pastel ou bleu)
        if (position % 2 == 0) {
            holder.appointmentTime.setBackgroundTintList(AppCompatResources.getColorStateList(holder.itemView.getContext(), R.color.pastel_green));
        } else {
            holder.appointmentTime.setBackgroundTintList(AppCompatResources.getColorStateList(holder.itemView.getContext(), R.color.bondi_blue));
        }

        holder.patientImage.setImageResource(R.drawable.default_profile_picture); // Image par défaut pour le patient

        // Gère le clic sur l'élément
        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onItemClick(appointment); // Appelle la méthode de l'interface
            }
        });
    }

    // Retourne le nombre total d'éléments dans la liste
    @Override
    public int getItemCount() {
        return appointmentList.size();
    }

    // Classe interne pour le ViewHolder
    public static class AppointmentViewHolder extends RecyclerView.ViewHolder {
        ImageView patientImage; // Image du patient
        TextView patientName; // Nom du patient
        TextView patientAge; // Âge du patient
        TextView appointmentType; // Type de rendez-vous
        TextView appointmentTime; // Heure du rendez-vous

        // Constructeur du ViewHolder
        public AppointmentViewHolder(View itemView) {
            super(itemView);

            // Initialise les vues à partir du layout
            patientImage = itemView.findViewById(R.id.activity_home_item_patient_picture);
            patientName = itemView.findViewById(R.id.activity_home_item_patient_name);
            patientAge = itemView.findViewById(R.id.activity_home_item_patient_age);
            appointmentType = itemView.findViewById(R.id.activity_home_item_appointment_type);
            appointmentTime = itemView.findViewById(R.id.activity_home_item_appointment_time);
        }
    }
}