package com.example.notifrdv.appointment;

import static android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT;
import static android.view.View.GONE;
import static android.view.View.VISIBLE;
import static com.example.notifrdv.utils.ConfirmationDialog.showConfirmationDialog;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.notifrdv.R;
import com.example.notifrdv.currentAppointment.CurrentAppointmentActivity;
import com.example.notifrdv.utils.database.Appointment;
import com.example.notifrdv.utils.database.Database;
import com.example.notifrdv.utils.database.Doctor;
import com.example.notifrdv.utils.database.Patient;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class AppointmentActivity extends AppCompatActivity {
    // Déclaration des éléments de l'interface utilisateur
    AutoCompleteTextView patientNameInput;
    AppCompatButton date;
    AppCompatButton time;

    Appointment appointment;
    String appointmentDate;
    String appointmentTime;
    long patientId;
    long doctorId;

    @SuppressLint({"SourceLockedOrientationActivity", "DefaultLocale"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_appointment);
        setRequestedOrientation(SCREEN_ORIENTATION_PORTRAIT);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialisation des éléments de la barre de statut personnalisée
        ImageView statusBackIcon = findViewById(R.id.status_bar_back_arrow_icon);
        ImageView statusBarIcon = findViewById(R.id.status_bar_icon);
        TextView statusBarTitle = findViewById(R.id.status_bar_title);
        statusBackIcon.setOnClickListener(v -> finish());
        statusBarIcon.setImageResource(R.drawable.scheduling_white);
        statusBarTitle.setText(getString(R.string.appointment));

        // Récupère la date et l'heure actuelles pour initialiser les champs
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);

        // Initialisation des éléments de l'interface
        patientNameInput = findViewById(R.id.appointment_activity_patient_name);
        date = findViewById(R.id.appointment_activity_appointment_date);
        time = findViewById(R.id.appointment_activity_appointment_time);
        ImageView cancelAppointment = findViewById(R.id.appointment_activity_cancel_appointment);
        ImageView startAppointment = findViewById(R.id.appointment_activity_start_appointment);
        AppCompatButton cancelButton = findViewById(R.id.appointment_activity_cancel_button);
        AppCompatButton saveButton = findViewById(R.id.appointment_activity_save_button);

        // Récupère les données du rendez-vous passé via l'intent (si modification)
        appointment = (Appointment) getIntent().getSerializableExtra("appointment");
        patientNameInput.setText(appointment != null ? appointment.getPatient().getName() : "");

        patientId = appointment != null ? appointment.getPatient().getId() : 0L;
        doctorId = appointment != null ? appointment.getDoctorId() : 0L;

        // Définir un doctorId par défaut si aucun n'est spécifié
        if (doctorId == 0) {
            List<Doctor> doctors = Database.getInstance().getAllDoctors();
            if (!doctors.isEmpty()) {
                doctorId = doctors.get(0).getId(); // Prendre le premier médecin
            } else {
                Toast.makeText(this, "No doctors available. Please add a doctor first.", Toast.LENGTH_SHORT).show();
                finish();
                return;
            }
        }

        // Gère la date du rendez-vous
        int tempAppointmentDate = appointment != null ? appointment.getAppointmentDate() : 0;
        if (tempAppointmentDate == 0) {
            appointmentDate = String.format("%04d-%02d-%02d", year, month + 1, day);
        } else {
            appointmentDate = String.format("%04d-%02d-%02d",
                    tempAppointmentDate / 10000,
                    (tempAppointmentDate % 10000) / 100,
                    tempAppointmentDate % 100);
        }
        date.setText(appointmentDate);

        // Gère l'heure du rendez-vous
        int tempAppointmentTime = appointment != null ? appointment.getAppointmentTime() : 0;
        if (tempAppointmentTime == 0) {
            appointmentTime = String.format("%02d:%02d", hour, minute);
        } else {
            appointmentTime = String.format("%02d:%02d",
                    tempAppointmentTime / 100,
                    tempAppointmentTime % 100);
        }
        time.setText(appointmentTime);

        // Vérifie si c'est un nouveau rendez-vous
        boolean isNewAppointment = getIntent().getBooleanExtra("isNewAppointment", false);

        // Configure l'interface selon qu'il s'agit d'un nouveau rendez-vous ou d'une modification
        if (isNewAppointment) {
            patientNameInput.setEnabled(true);
            cancelAppointment.setVisibility(GONE);
            cancelButton.setVisibility(VISIBLE);
        } else {
            patientNameInput.setEnabled(false);
            cancelAppointment.setVisibility(VISIBLE);
            cancelButton.setVisibility(GONE);
        }

        // Charge la liste des patients depuis la base de données pour l'autocomplétion
        List<String> patients = new ArrayList<>();
        for (Patient patient : Database.getInstance().getAllPatients()) {
            patients.add(patient.getName());
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, patients);
        patientNameInput.setAdapter(adapter);
        patientNameInput.setOnItemClickListener((parent, view, position, id) -> {
            String selectedPatientName = patients.get(position);
            Patient selectedPatient = Database.getInstance().getPatientByName(selectedPatientName);
            if (selectedPatient != null) {
                patientId = selectedPatient.getId();
            }
        });

        // Ajoute un DatePickerDialog pour le bouton date
        date.setOnClickListener(v -> {
            DatePickerDialog datePickerDialog = new DatePickerDialog(
                    AppointmentActivity.this,
                    (view, yearSelected, monthSelected, dayOfMonth) -> {
                        appointmentDate = String.format("%04d-%02d-%02d", yearSelected, monthSelected + 1, dayOfMonth);
                        date.setText(appointmentDate);
                    },
                    year, month, day
            );
            datePickerDialog.show();
        });

        // Ajoute un TimePickerDialog pour le bouton time
        time.setOnClickListener(v -> {
            TimePickerDialog timePickerDialog = new TimePickerDialog(
                    AppointmentActivity.this,
                    (view, hourOfDay, minuteOfHour) -> {
                        appointmentTime = String.format("%02d:%02d", hourOfDay, minuteOfHour);
                        time.setText(appointmentTime);
                    },
                    hour, minute, true
            );
            timePickerDialog.show();
        });

        // Gère le clic sur l'icône d'annulation du rendez-vous
        cancelAppointment.setOnClickListener(v ->
                showConfirmationDialog(
                        this,
                        "Cancel Appointment",
                        "Are you sure you want to cancel this appointment?",
                        "Yes",
                        "No",
                        () -> {
                            Database.getInstance().deleteAppointment(appointment);
                            finish();
                        },
                        () -> {}
                )
        );

        // Gère le clic sur l'icône de démarrage du rendez-vous
        startAppointment.setOnClickListener(v -> {
            if (!isAppointmentValid() || Database.getInstance().getPatientById(patientId) == null) {
                Toast.makeText(this, "Invalid appointment data.", Toast.LENGTH_SHORT).show();
                return;
            }

            saveUpdateAppointment();
            Intent intent = new Intent(AppointmentActivity.this, CurrentAppointmentActivity.class);
            intent.putExtra("appointment", appointment);
            startActivity(intent);
            finish();
        });

        // Gère le clic sur le bouton de sauvegarde
        saveButton.setOnClickListener(v -> {
            if (!isAppointmentValid() || Database.getInstance().getPatientById(patientId) == null) {
                Toast.makeText(this, "Invalid appointment data.", Toast.LENGTH_SHORT).show();
                return;
            }

            saveUpdateAppointment();
            finish();
        });

        // Gère le clic sur le bouton d'annulation de l'action
        cancelButton.setOnClickListener(v -> showConfirmationDialog(
                this,
                "Cancel Appointment",
                "Are you sure you want to cancel this action?\nUnsaved changes will be lost.",
                "Yes",
                "No",
                this::finish,
                () -> {}
        ));
    }

    private boolean isAppointmentValid() {
        // Validation basique des données
        return patientId != 0 && appointmentDate != null && !appointmentDate.isEmpty() && appointmentTime != null && !appointmentTime.isEmpty();
    }

    private void saveUpdateAppointment() {
        if (appointment == null) {
            // Création d'un nouvel appointment
            Patient patient = Database.getInstance().getPatientByName(patientNameInput.getText().toString());
            if (patient != null) {
                appointment = new Appointment(
                        0, // id sera généré par la base
                        patient,
                        doctorId,
                        Integer.parseInt(appointmentDate.replace("-", "")),
                        Integer.parseInt(appointmentTime.replace(":", "")),
                        "",
                        false
                );
                Database.getInstance().addAppointment(appointment, doctorId);
            } else {
                Toast.makeText(this, "Patient not found.", Toast.LENGTH_SHORT).show();
            }
        } else {
            // Mise à jour d'un appointment existant
            Patient patient = Database.getInstance().getPatientByName(patientNameInput.getText().toString());
            if (patient != null) {
                appointment.setAppointmentDate(Integer.parseInt(appointmentDate.replace("-", "")));
                appointment.setAppointmentTime(Integer.parseInt(appointmentTime.replace(":", "")));
                appointment.setNotes(""); // À ajuster si tu veux permettre la modification des notes
                Database.getInstance().updateAppointment(appointment, doctorId);
            } else {
                Toast.makeText(this, "Patient not found for update.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}