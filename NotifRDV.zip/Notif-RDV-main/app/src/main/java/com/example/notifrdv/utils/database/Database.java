package com.example.notifrdv.utils.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Base64;
import android.util.Log;

import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

public class Database extends SQLiteOpenHelper {
    private static Database instance;
    private static final String DATABASE_NAME = "notif_rdv";
    private static final int DATABASE_VERSION = 1;

    public static synchronized Database getInstance() {
        if (instance == null) {
            throw new IllegalStateException("Database instance is not initialized. Call initializeInstance() first.");
        }
        return instance;
    }

    public static synchronized void initializeInstance(Context context) {
        if (instance == null) {
            instance = new Database(context);
        }
    }

    private Database(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE doctors (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "name TEXT NOT NULL, " +
                "email TEXT UNIQUE NOT NULL, " +
                "password TEXT NOT NULL, " +
                "salt TEXT NOT NULL, " +
                "picture_path TEXT)");

        db.execSQL("CREATE TABLE patients (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "name TEXT NOT NULL, " +
                "date_of_birth INTEGER NOT NULL, " +
                "email TEXT UNIQUE NOT NULL, " +
                "phone_number TEXT NOT NULL, " +
                "picture_path TEXT)");

        db.execSQL("CREATE TABLE appointments (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "patient_id INTEGER NOT NULL, " +
                "doctor_id INTEGER NOT NULL, " +
                "appointment_date INTEGER NOT NULL, " +
                "appointment_time INTEGER NOT NULL, " +
                "notes TEXT, " +
                "done INTEGER NOT NULL DEFAULT 0, " +
                "FOREIGN KEY(patient_id) REFERENCES patients(id), " +
                "FOREIGN KEY(doctor_id) REFERENCES doctors(id))");

        db.execSQL("CREATE TABLE prescriptions (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "appointment_id INTEGER NOT NULL, " +
                "medicine_name TEXT NOT NULL, " +
                "dosage TEXT NOT NULL, " +
                "duration TEXT NOT NULL, " +
                "FOREIGN KEY(appointment_id) REFERENCES appointments(id))");

        db.execSQL("CREATE TABLE examinations (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "appointment_id INTEGER NOT NULL, " +
                "exam_type TEXT NOT NULL, " +
                "result TEXT, " +
                "exam_date INTEGER NOT NULL, " +
                "FOREIGN KEY(appointment_id) REFERENCES appointments(id))");

        db.execSQL("CREATE TABLE medical_history (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "patient_id INTEGER NOT NULL, " +
                "condition TEXT NOT NULL, " +
                "diagnosis_date INTEGER NOT NULL, " +
                "treatment TEXT, " +
                "FOREIGN KEY(patient_id) REFERENCES patients(id))");

        Log.d("Database", "Database and tables created successfully");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS medical_history");
        db.execSQL("DROP TABLE IF EXISTS examinations");
        db.execSQL("DROP TABLE IF EXISTS prescriptions");
        db.execSQL("DROP TABLE IF EXISTS appointments");
        db.execSQL("DROP TABLE IF EXISTS patients");
        db.execSQL("DROP TABLE IF EXISTS doctors");
        onCreate(db);
    }

    private String generateSalt() {
        SecureRandom random = new SecureRandom();
        byte[] salt = new byte[16];
        random.nextBytes(salt);
        return Base64.encodeToString(salt, Base64.DEFAULT);
    }

    private String hashPassword(String password, String salt) {
        try {
            int iterations = 10000;
            char[] chars = password.toCharArray();
            byte[] saltBytes = Base64.decode(salt, Base64.DEFAULT);
            PBEKeySpec spec = new PBEKeySpec(chars, saltBytes, iterations, 256);
            SecretKeyFactory skf = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
            byte[] hash = skf.generateSecret(spec).getEncoded();
            return Base64.encodeToString(hash, Base64.DEFAULT);
        } catch (Exception e) {
            Log.e("Database", "Error hashing password: " + e.getMessage());
            return null;
        }
    }

    // Doctor methods
    public long addDoctor(String name, String email, String password, String picturePath) {
        SQLiteDatabase db = getWritableDatabase();
        try {
            String salt = generateSalt();
            String hashedPassword = hashPassword(password, salt);
            if (hashedPassword == null) {
                return -1;
            }
            ContentValues values = new ContentValues();
            values.put("name", name);
            values.put("email", email);
            values.put("password", hashedPassword);
            values.put("salt", salt);
            values.put("picture_path", picturePath);
            long result = db.insert("doctors", null, values);
            Log.d("Database", "addDoctor: Inserted doctor with email " + email + ", result: " + result);
            return result;
        } catch (Exception e) {
            Log.e("Database", "Error adding doctor: " + e.getMessage());
            return -1;
        }
    }

    public Doctor getDoctorById(long doctorId) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = null;
        try {
            cursor = db.query("doctors", null, "id = ?", new String[]{String.valueOf(doctorId)}, null, null, null);
            if (cursor.moveToFirst()) {
                Doctor doctor = new Doctor(
                        cursor.getLong(cursor.getColumnIndexOrThrow("id")),
                        cursor.getString(cursor.getColumnIndexOrThrow("name")),
                        cursor.getString(cursor.getColumnIndexOrThrow("email")),
                        cursor.getString(cursor.getColumnIndexOrThrow("password")),
                        cursor.getString(cursor.getColumnIndexOrThrow("picture_path"))
                );
                Log.d("Database", "getDoctorById: Found doctor with ID " + doctorId);
                return doctor;
            }
            Log.d("Database", "getDoctorById: No doctor found with ID " + doctorId);
            return null;
        } catch (Exception e) {
            Log.e("Database", "Error retrieving doctor by ID: " + e.getMessage());
            return null;
        } finally {
            if (cursor != null) cursor.close();
        }
    }

    public Doctor getDoctorByName(String name) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = null;
        try {
            cursor = db.query("doctors", null, "name = ?", new String[]{name}, null, null, null);
            if (cursor.moveToFirst()) {
                Doctor doctor = new Doctor(
                        cursor.getLong(cursor.getColumnIndexOrThrow("id")),
                        cursor.getString(cursor.getColumnIndexOrThrow("name")),
                        cursor.getString(cursor.getColumnIndexOrThrow("email")),
                        cursor.getString(cursor.getColumnIndexOrThrow("password")),
                        cursor.getString(cursor.getColumnIndexOrThrow("picture_path"))
                );
                Log.d("Database", "getDoctorByName: Found doctor with name " + name);
                return doctor;
            }
            Log.d("Database", "getDoctorByName: No doctor found with name " + name);
            return null;
        } catch (Exception e) {
            Log.e("Database", "Error retrieving doctor by name: " + e.getMessage());
            return null;
        } finally {
            if (cursor != null) cursor.close();
        }
    }

    public Doctor getDoctorByEmail(String email, String password) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = null;
        try {
            cursor = db.query("doctors", null, "email = ?", new String[]{email}, null, null, null);
            if (cursor.moveToFirst()) {
                String storedHash = cursor.getString(cursor.getColumnIndexOrThrow("password"));
                String salt = cursor.getString(cursor.getColumnIndexOrThrow("salt"));
                String hashedPassword = hashPassword(password, salt);
                if (hashedPassword != null && hashedPassword.equals(storedHash)) {
                    Doctor doctor = new Doctor(
                            cursor.getLong(cursor.getColumnIndexOrThrow("id")),
                            cursor.getString(cursor.getColumnIndexOrThrow("name")),
                            cursor.getString(cursor.getColumnIndexOrThrow("email")),
                            storedHash,
                            cursor.getString(cursor.getColumnIndexOrThrow("picture_path"))
                    );
                    Log.d("Database", "getDoctorByEmail: Found doctor with email " + email);
                    return doctor;
                }
            }
            Log.d("Database", "getDoctorByEmail: No doctor found with email " + email + " or password mismatch");
            return null;
        } catch (Exception e) {
            Log.e("Database", "Error retrieving doctor by email: " + e.getMessage());
            return null;
        } finally {
            if (cursor != null) cursor.close();
        }
    }

    public void updateDoctor(long doctorId, String name, String email, String password, String picturePath) {
        SQLiteDatabase db = getWritableDatabase();
        try {
            String salt = generateSalt();
            String hashedPassword = hashPassword(password, salt);
            if (hashedPassword == null) {
                return;
            }
            ContentValues values = new ContentValues();
            values.put("name", name);
            values.put("email", email);
            values.put("password", hashedPassword);
            values.put("salt", salt);
            values.put("picture_path", picturePath);
            int rows = db.update("doctors", values, "id = ?", new String[]{String.valueOf(doctorId)});
            Log.d("Database", "updateDoctor: Updated " + rows + " rows for doctor ID " + doctorId);
        } catch (Exception e) {
            Log.e("Database", "Error updating doctor: " + e.getMessage());
        }
    }

    public List<Doctor> getAllDoctors() {
        List<Doctor> doctors = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = null;
        try {
            cursor = db.query("doctors", null, null, null, null, null, null);
            while (cursor.moveToNext()) {
                doctors.add(new Doctor(
                        cursor.getLong(cursor.getColumnIndexOrThrow("id")),
                        cursor.getString(cursor.getColumnIndexOrThrow("name")),
                        cursor.getString(cursor.getColumnIndexOrThrow("email")),
                        cursor.getString(cursor.getColumnIndexOrThrow("password")),
                        cursor.getString(cursor.getColumnIndexOrThrow("picture_path"))
                ));
            }
            Log.d("Database", "getAllDoctors: Retrieved " + doctors.size() + " doctors");
            return doctors;
        } catch (Exception e) {
            Log.e("Database", "Error retrieving all doctors: " + e.getMessage());
            return doctors;
        } finally {
            if (cursor != null) cursor.close();
        }
    }

    // Patient methods
    public long addPatient(String name, int dateOfBirth, String email, String phoneNumber, String picturePath) {
        SQLiteDatabase db = getWritableDatabase();
        try {
            ContentValues values = new ContentValues();
            values.put("name", name);
            values.put("date_of_birth", dateOfBirth);
            values.put("email", email);
            values.put("phone_number", phoneNumber);
            values.put("picture_path", picturePath);
            return db.insert("patients", null, values);
        } catch (Exception e) {
            Log.e("Database", "Error adding patient: " + e.getMessage());
            return -1;
        }
    }

    public long addPatient(Patient patient) {
        SQLiteDatabase db = getWritableDatabase();
        try {
            ContentValues values = new ContentValues();
            values.put("name", patient.getName());
            values.put("date_of_birth", patient.getBirthdate());
            values.put("email", patient.getEmail());
            values.put("phone_number", patient.getPhone());
            values.put("picture_path", patient.getPicturePath());
            return db.insert("patients", null, values);
        } catch (Exception e) {
            Log.e("Database", "Error adding patient: " + e.getMessage());
            return -1;
        }
    }

    public Patient getPatientById(long patientId) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = null;
        try {
            cursor = db.query("patients", null, "id = ?", new String[]{String.valueOf(patientId)}, null, null, null);
            if (cursor.moveToFirst()) {
                Patient patient = new Patient(
                        cursor.getLong(cursor.getColumnIndexOrThrow("id")),
                        cursor.getString(cursor.getColumnIndexOrThrow("name")),
                        cursor.getInt(cursor.getColumnIndexOrThrow("date_of_birth")),
                        cursor.getString(cursor.getColumnIndexOrThrow("email")),
                        cursor.getString(cursor.getColumnIndexOrThrow("phone_number")),
                        cursor.getString(cursor.getColumnIndexOrThrow("picture_path"))
                );
                return patient;
            }
            return null;
        } catch (Exception e) {
            Log.e("Database", "Error retrieving patient by ID: " + e.getMessage());
            return null;
        } finally {
            if (cursor != null) cursor.close();
        }
    }

    public List<Patient> getAllPatients() {
        List<Patient> patients = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = null;
        try {
            cursor = db.query("patients", null, null, null, null, null, "name ASC");
            while (cursor.moveToNext()) {
                Patient patient = new Patient(
                        cursor.getLong(cursor.getColumnIndexOrThrow("id")),
                        cursor.getString(cursor.getColumnIndexOrThrow("name")),
                        cursor.getInt(cursor.getColumnIndexOrThrow("date_of_birth")),
                        cursor.getString(cursor.getColumnIndexOrThrow("email")),
                        cursor.getString(cursor.getColumnIndexOrThrow("phone_number")),
                        cursor.getString(cursor.getColumnIndexOrThrow("picture_path"))
                );
                patients.add(patient);
            }
            return patients;
        } catch (Exception e) {
            Log.e("Database", "Error retrieving all patients: " + e.getMessage());
            return patients;
        } finally {
            if (cursor != null) cursor.close();
        }
    }

    public Patient getPatientByEmail(String email) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = null;
        try {
            cursor = db.query("patients", null, "email = ?", new String[]{email}, null, null, null);
            if (cursor.moveToFirst()) {
                Patient patient = new Patient(
                        cursor.getLong(cursor.getColumnIndexOrThrow("id")),
                        cursor.getString(cursor.getColumnIndexOrThrow("name")),
                        cursor.getInt(cursor.getColumnIndexOrThrow("date_of_birth")),
                        cursor.getString(cursor.getColumnIndexOrThrow("email")),
                        cursor.getString(cursor.getColumnIndexOrThrow("phone_number")),
                        cursor.getString(cursor.getColumnIndexOrThrow("picture_path"))
                );
                return patient;
            }
            return null;
        } catch (Exception e) {
            Log.e("Database", "Error retrieving patient by email: " + e.getMessage());
            return null;
        } finally {
            if (cursor != null) cursor.close();
        }
    }

    public Patient getPatientByName(String name) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = null;
        try {
            cursor = db.query("patients", null, "name = ?", new String[]{name}, null, null, null);
            if (cursor.moveToFirst()) {
                Patient patient = new Patient(
                        cursor.getLong(cursor.getColumnIndexOrThrow("id")),
                        cursor.getString(cursor.getColumnIndexOrThrow("name")),
                        cursor.getInt(cursor.getColumnIndexOrThrow("date_of_birth")),
                        cursor.getString(cursor.getColumnIndexOrThrow("email")),
                        cursor.getString(cursor.getColumnIndexOrThrow("phone_number")),
                        cursor.getString(cursor.getColumnIndexOrThrow("picture_path"))
                );
                return patient;
            }
            return null;
        } catch (Exception e) {
            Log.e("Database", "Error retrieving patient by name: " + e.getMessage());
            return null;
        } finally {
            if (cursor != null) cursor.close();
        }
    }

    public void updatePatient(Patient patient) {
        SQLiteDatabase db = getWritableDatabase();
        try {
            ContentValues values = new ContentValues();
            values.put("name", patient.getName());
            values.put("date_of_birth", patient.getBirthdate());
            values.put("email", patient.getEmail());
            values.put("phone_number", patient.getPhone());
            values.put("picture_path", patient.getPicturePath());
            db.update("patients", values, "id = ?", new String[]{String.valueOf(patient.getId())});
        } catch (Exception e) {
            Log.e("Database", "Error updating patient: " + e.getMessage());
        }
    }

    // Appointment methods
    public long addAppointment(Appointment appointment, long doctorId) {
        SQLiteDatabase db = getWritableDatabase();
        try {
            ContentValues values = new ContentValues();
            values.put("patient_id", appointment.getPatient().getId());
            values.put("doctor_id", doctorId);
            values.put("appointment_date", appointment.getAppointmentDate());
            values.put("appointment_time", appointment.getAppointmentTime());
            values.put("notes", appointment.getNotes());
            values.put("done", appointment.isDone() ? 1 : 0);
            return db.insert("appointments", null, values);
        } catch (Exception e) {
            Log.e("Database", "Error adding appointment: " + e.getMessage());
            return -1;
        }
    }

    public void updateAppointment(Appointment appointment, long doctorId) {
        SQLiteDatabase db = getWritableDatabase();
        try {
            ContentValues values = new ContentValues();
            values.put("patient_id", appointment.getPatient().getId());
            values.put("doctor_id", doctorId);
            values.put("appointment_date", appointment.getAppointmentDate());
            values.put("appointment_time", appointment.getAppointmentTime());
            values.put("notes", appointment.getNotes());
            values.put("done", appointment.isDone() ? 1 : 0);
            db.update("appointments", values, "id = ?", new String[]{String.valueOf(appointment.getId())});
        } catch (Exception e) {
            Log.e("Database", "Error updating appointment: " + e.getMessage());
        }
    }

    public void deleteAppointment(Appointment appointment) {
        SQLiteDatabase db = getWritableDatabase();
        try {
            db.delete("appointments", "id = ?", new String[]{String.valueOf(appointment.getId())});
        } catch (Exception e) {
            Log.e("Database", "Error deleting appointment: " + e.getMessage());
        }
    }

    public Appointment getPreviousDoneAppointmentByPatientId(long patientId) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = null;
        try {
            cursor = db.query(
                    "appointments",
                    null,
                    "patient_id = ? AND done = ?",
                    new String[]{String.valueOf(patientId), "1"},
                    null,
                    null,
                    "appointment_date DESC, appointment_time DESC",
                    "1"
            );
            if (cursor.moveToFirst()) {
                return new Appointment(
                        cursor.getLong(cursor.getColumnIndexOrThrow("id")),
                        getPatientById(cursor.getLong(cursor.getColumnIndexOrThrow("patient_id"))),
                        cursor.getLong(cursor.getColumnIndexOrThrow("doctor_id")),
                        "",
                        cursor.getInt(cursor.getColumnIndexOrThrow("appointment_date")),
                        cursor.getInt(cursor.getColumnIndexOrThrow("appointment_time")),
                        cursor.getString(cursor.getColumnIndexOrThrow("notes")),
                        "",
                        "",
                        cursor.getInt(cursor.getColumnIndexOrThrow("done")) == 1
                );
            }
            return null;
        } catch (Exception e) {
            Log.e("Database", "Error retrieving previous done appointment: " + e.getMessage());
            return null;
        } finally {
            if (cursor != null) cursor.close();
        }
    }

    public List<Appointment> getAllNotDoneAppointmentsByDate(int date) {
        List<Appointment> appointments = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = null;
        try {
            cursor = db.query(
                    "appointments",
                    null,
                    "appointment_date = ? AND done = ?",
                    new String[]{String.valueOf(date), "0"},
                    null,
                    null,
                    "appointment_time ASC"
            );
            while (cursor.moveToNext()) {
                appointments.add(new Appointment(
                        cursor.getLong(cursor.getColumnIndexOrThrow("id")),
                        getPatientById(cursor.getLong(cursor.getColumnIndexOrThrow("patient_id"))),
                        cursor.getLong(cursor.getColumnIndexOrThrow("doctor_id")),
                        "",
                        cursor.getInt(cursor.getColumnIndexOrThrow("appointment_date")),
                        cursor.getInt(cursor.getColumnIndexOrThrow("appointment_time")),
                        cursor.getString(cursor.getColumnIndexOrThrow("notes")),
                        "",
                        "",
                        cursor.getInt(cursor.getColumnIndexOrThrow("done")) == 1
                ));
            }
            return appointments;
        } catch (Exception e) {
            Log.e("Database", "Error retrieving appointments by date: " + e.getMessage());
            return appointments;
        } finally {
            if (cursor != null) cursor.close();
        }
    }

    public List<Appointment> getTodayAppointments() {
        List<Appointment> todayAppointments = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = null;
        try {
            Calendar calendar = Calendar.getInstance();
            int year = calendar.get(Calendar.YEAR);
            int month = calendar.get(Calendar.MONTH) + 1;
            int day = calendar.get(Calendar.DAY_OF_MONTH);
            int today = year * 10000 + month * 100 + day;
            cursor = db.query(
                    "appointments",
                    null,
                    "appointment_date = ? AND done = ?",
                    new String[]{String.valueOf(today), "0"},
                    null,
                    null,
                    "appointment_time ASC"
            );
            while (cursor.moveToNext()) {
                todayAppointments.add(new Appointment(
                        cursor.getLong(cursor.getColumnIndexOrThrow("id")),
                        getPatientById(cursor.getLong(cursor.getColumnIndexOrThrow("patient_id"))),
                        cursor.getLong(cursor.getColumnIndexOrThrow("doctor_id")),
                        "",
                        cursor.getInt(cursor.getColumnIndexOrThrow("appointment_date")),
                        cursor.getInt(cursor.getColumnIndexOrThrow("appointment_time")),
                        cursor.getString(cursor.getColumnIndexOrThrow("notes")),
                        "",
                        "",
                        cursor.getInt(cursor.getColumnIndexOrThrow("done")) == 1
                ));
            }
            return todayAppointments;
        } catch (Exception e) {
            Log.e("Database", "Error retrieving today's appointments: " + e.getMessage());
            return todayAppointments;
        } finally {
            if (cursor != null) cursor.close();
        }
    }

    // Prescription methods
    public long addPrescription(long appointmentId, String medicineName, String dosage, String duration) {
        SQLiteDatabase db = getWritableDatabase();
        try {
            ContentValues values = new ContentValues();
            values.put("appointment_id", appointmentId);
            values.put("medicine_name", medicineName);
            values.put("dosage", dosage);
            values.put("duration", duration);
            return db.insert("prescriptions", null, values);
        } catch (Exception e) {
            Log.e("Database", "Error adding prescription: " + e.getMessage());
            return -1;
        }
    }

    public List<String> getPrescriptionsForAppointment(long appointmentId) {
        List<String> prescriptions = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = null;
        try {
            cursor = db.query("prescriptions", null, "appointment_id = ?", new String[]{String.valueOf(appointmentId)}, null, null, null);
            while (cursor.moveToNext()) {
                String medicine = cursor.getString(cursor.getColumnIndexOrThrow("medicine_name"));
                String dosage = cursor.getString(cursor.getColumnIndexOrThrow("dosage"));
                String duration = cursor.getString(cursor.getColumnIndexOrThrow("duration"));
                prescriptions.add(medicine + " - " + dosage + " for " + duration);
            }
            return prescriptions;
        } catch (Exception e) {
            Log.e("Database", "Error retrieving prescriptions: " + e.getMessage());
            return prescriptions;
        } finally {
            if (cursor != null) cursor.close();
        }
    }

    // Examination methods
    public long addExamination(long appointmentId, String examType, String result, int examDate) {
        SQLiteDatabase db = getWritableDatabase();
        try {
            ContentValues values = new ContentValues();
            values.put("appointment_id", appointmentId);
            values.put("exam_type", examType);
            values.put("result", result);
            values.put("exam_date", examDate);
            return db.insert("examinations", null, values);
        } catch (Exception e) {
            Log.e("Database", "Error adding examination: " + e.getMessage());
            return -1;
        }
    }

    public List<String> getExaminationsForAppointment(long appointmentId) {
        List<String> examinations = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = null;
        try {
            cursor = db.query("examinations", null, "appointment_id = ?", new String[]{String.valueOf(appointmentId)}, null, null, null);
            while (cursor.moveToNext()) {
                String examType = cursor.getString(cursor.getColumnIndexOrThrow("exam_type"));
                String result = cursor.getString(cursor.getColumnIndexOrThrow("result"));
                int examDate = cursor.getInt(cursor.getColumnIndexOrThrow("exam_date"));
                examinations.add(examType + " on " + examDate + ": " + result);
            }
            return examinations;
        } catch (Exception e) {
            Log.e("Database", "Error retrieving examinations: " + e.getMessage());
            return examinations;
        } finally {
            if (cursor != null) cursor.close();
        }
    }

    // Medical History methods
    public long addMedicalHistory(long patientId, String condition, int diagnosisDate, String treatment) {
        SQLiteDatabase db = getWritableDatabase();
        try {
            ContentValues values = new ContentValues();
            values.put("patient_id", patientId);
            values.put("condition", condition);
            values.put("diagnosis_date", diagnosisDate);
            values.put("treatment", treatment);
            return db.insert("medical_history", null, values);
        } catch (Exception e) {
            Log.e("Database", "Error adding medical history: " + e.getMessage());
            return -1;
        }
    }

    public List<String> getMedicalHistoryForPatient(long patientId) {
        List<String> history = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = null;
        try {
            cursor = db.query("medical_history", null, "patient_id = ?", new String[]{String.valueOf(patientId)}, null, null, "diagnosis_date DESC");
            while (cursor.moveToNext()) {
                String condition = cursor.getString(cursor.getColumnIndexOrThrow("condition"));
                int diagnosisDate = cursor.getInt(cursor.getColumnIndexOrThrow("diagnosis_date"));
                String treatment = cursor.getString(cursor.getColumnIndexOrThrow("treatment"));
                history.add(condition + " diagnosed on " + diagnosisDate + ": " + treatment);
            }
            return history;
        } catch (Exception e) {
            Log.e("Database", "Error retrieving medical history: " + e.getMessage());
            return history;
        } finally {
            if (cursor != null) cursor.close();
        }
    }
}