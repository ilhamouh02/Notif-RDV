package com.example.notifrdv.utils.database;

import java.io.Serializable;

public class Appointment implements Serializable {
    private long id;
    private Patient patient;
    private long doctorId;
    private String appointmentType;
    private int appointmentDate;
    private int appointmentTime;
    private String notes;
    private String medicines;
    private String exams;
    private boolean done;

    public Appointment(long id, Patient patient, long doctorId, String appointmentType, int appointmentDate, int appointmentTime, String notes, String medicines, String exams, boolean done) {
        this.id = id;
        this.patient = patient;
        this.doctorId = doctorId;
        this.appointmentType = appointmentType;
        this.appointmentDate = appointmentDate;
        this.appointmentTime = appointmentTime;
        this.notes = notes;
        this.medicines = medicines;
        this.exams = exams;
        this.done = done;
    }

    public long getId() {
        return id;
    }

    public Patient getPatient() {
        return patient;
    }

    public long getDoctorId() {
        return doctorId;
    }

    public String getAppointmentType() {
        return appointmentType;
    }

    public int getAppointmentDate() {
        return appointmentDate;
    }

    public int getAppointmentTime() {
        return appointmentTime;
    }

    public String getNotes() {
        return notes;
    }

    public String getMedicines() {
        return medicines;
    }

    public String getExams() {
        return exams;
    }

    public boolean isDone() {
        return done;
    }
}