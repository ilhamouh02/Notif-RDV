package com.example.notifrdv.patientRecords;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.notifrdv.utils.database.Patient;
import java.util.List;

public class PatientRecordsActivityPatientAdapter extends RecyclerView.Adapter<PatientRecordsActivityPatientAdapter.ViewHolder> {
    private List<Patient> patients;
    private final OnItemClickListener listener;

    public interface OnItemClickListener {
        void onItemClick(Patient patient);
    }

    public PatientRecordsActivityPatientAdapter(List<Patient> patients, OnItemClickListener listener) {
        this.patients = patients;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(android.R.layout.simple_list_item_1, parent, false);
        return new ViewHolder(view);
    }


    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView patientName;

        ViewHolder(View itemView) {
            super(itemView);
            patientName = itemView.findViewById(android.R.id.text1);
        }
    }
}