package com.example.notifrdv.home;

import static android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.notifrdv.R;
import com.example.notifrdv.appointment.AppointmentActivity;
import com.example.notifrdv.doctorProfile.DoctorProfileActivity;
import com.example.notifrdv.patientRecords.PatientRecordsActivity;
import com.example.notifrdv.utils.database.Appointment;
import com.example.notifrdv.utils.database.Database;
import com.example.notifrdv.utils.database.Doctor;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class HomeActivity extends AppCompatActivity implements HomeActivityAppointmentsAdapter.OnItemClickListener {
    ImageView doctorImage;
    ImageButton editButton;
    TextView doctorName;
    TextView appointmentsCounter;
    TextView nextAppointment;

    List<Appointment> appointments;
    RecyclerView upcomingAppointments;
    HomeActivityAppointmentsAdapter adapter;

    @SuppressLint({"SetTextI18n", "SourceLockedOrientationActivity"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_home);
        setRequestedOrientation(SCREEN_ORIENTATION_PORTRAIT);

        // Initialize Database
        try {
            Database.initializeInstance(getApplicationContext());
        } catch (Exception e) {
            Log.e("HomeActivity", "Failed to initialize database: " + e.getMessage());
            return;
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        doctorImage = findViewById(R.id.home_activity_doctor_picture);
        Log.d("HomeActivityDebug", "doctorImage: " + (doctorImage != null ? doctorImage.getClass().getName() : "null"));
        editButton = findViewById(R.id.home_activity_edit_doctor_info);
        Log.d("HomeActivityDebug", "editButton: " + (editButton != null ? editButton.getClass().getName() : "null"));
        doctorName = findViewById(R.id.home_activity_doctor_name);
        Log.d("HomeActivityDebug", "doctorName: " + (doctorName != null ? doctorName.getClass().getName() : "null"));
        appointmentsCounter = findViewById(R.id.home_activity_doctor_appointments_counter);
        Log.d("HomeActivityDebug", "appointmentsCounter: " + (appointmentsCounter != null ? appointmentsCounter.getClass().getName() : "null"));
        nextAppointment = findViewById(R.id.home_activity_doctor_next_appointment);
        Log.d("HomeActivityDebug", "nextAppointment: " + (nextAppointment != null ? nextAppointment.getClass().getName() : "null"));

        LinearLayout appointmentsScheduling = findViewById(R.id.home_activity_appointments_scheduling_layout);
        Log.d("HomeActivityDebug", "appointmentsScheduling: " + (appointmentsScheduling != null ? appointmentsScheduling.getClass().getName() : "null"));
        LinearLayout patientRecords = findViewById(R.id.home_activity_patients_records_layout);
        Log.d("HomeActivityDebug", "patientRecords: " + (patientRecords != null ? patientRecords.getClass().getName() : "null"));

        upcomingAppointments = findViewById(R.id.home_activity_upcoming_appointments_list);
        Log.d("HomeActivityDebug", "upcomingAppointments: " + (upcomingAppointments != null ? upcomingAppointments.getClass().getName() : "null"));

        appointments = new ArrayList<>();
        adapter = new HomeActivityAppointmentsAdapter(appointments, this);
        upcomingAppointments.setLayoutManager(new LinearLayoutManager(this));
        upcomingAppointments.setAdapter(adapter);

        editButton.setOnClickListener(v -> startActivity(new Intent(HomeActivity.this, DoctorProfileActivity.class)));
        if (appointmentsScheduling != null) {
            appointmentsScheduling.setOnClickListener(v -> {
                Intent intent = new Intent(HomeActivity.this, AppointmentActivity.class);
                intent.putExtra("isNewAppointment", true);
                startActivity(intent);
            });
        }
        if (patientRecords != null) {
            patientRecords.setOnClickListener(v -> startActivity(new Intent(HomeActivity.this, PatientRecordsActivity.class)));
        }
    }

    @SuppressLint({"NotifyDataSetChanged", "SetTextI18n", "DefaultLocale"})
    @Override
    protected void onResume() {
        super.onResume();

        // Load doctor information
        String email = getIntent().getStringExtra("email");
        Log.d("HomeActivityDebug", "Email: " + email);
        if (email != null) {
            Doctor doctor = Database.getInstance().getDoctorByEmail(email);
            if (doctor != null) {
                doctorName.setText("Dr. " + doctor.getName());
                String picturePath = doctor.getPicturePath();
                if (picturePath != null && !picturePath.isEmpty()) {
                    File imgFile = new File(picturePath);
                    if (imgFile.exists()) {
                        Bitmap bitmap = BitmapFactory.decodeFile(imgFile.getAbsolutePath());
                        doctorImage.setImageBitmap(bitmap);
                    } else {
                        doctorImage.setImageResource(R.drawable.default_profile_picture);
                    }
                } else {
                    doctorImage.setImageResource(R.drawable.default_profile_picture);
                }
            } else {
                Log.e("HomeActivity", "Doctor not found for email: " + email);
                doctorName.setText("Dr. Unknown");
                doctorImage.setImageResource(R.drawable.default_profile_picture);
            }
        } else {
            Log.e("HomeActivity", "No email provided in intent");
            doctorName.setText("Dr. Unknown");
            doctorImage.setImageResource(R.drawable.default_profile_picture);
        }
    }

    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
        // Do nothing to prevent back navigation
    }

    @Override
    public void onItemClick(Appointment appointment) {
        Intent intent = new Intent(HomeActivity.this, AppointmentActivity.class);
        intent.putExtra("appointment", appointment);
        startActivity(intent);
    }
}